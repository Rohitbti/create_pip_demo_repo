def function_add(number):
    return number + 1 
 
